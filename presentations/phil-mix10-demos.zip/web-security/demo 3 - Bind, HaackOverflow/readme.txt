For this demo, use the HaackOverflow.sln from the intro-mvc folder.

This is exactly what Scott and I should have done during our 
talk at Mix. (http://live.visitmix.com/MIX10/Sessions/FT05).
Near the end of the talk, we have a demo that completely fails 
because we're running the wrong version of the app. ;)
