function toggleView() {
    document.moviesapp.view.value = (document.moviesapp.view.value == "Theater") ? "Movie" : "Theater";
}