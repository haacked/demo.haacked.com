﻿using System.IO;
using System.Web.Util;

namespace NerdDinner.Helpers
{
    public class SuperNerdEncoder : AntiXssEncoder
    {
        
    }
}