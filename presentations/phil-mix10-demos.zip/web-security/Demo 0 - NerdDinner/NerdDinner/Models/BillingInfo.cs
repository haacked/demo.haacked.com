﻿using System.ComponentModel;

namespace NerdDinner.Models
{
    public class BillingInfo
    {
        [DisplayName("First Name")]
        public string FirstName { get; set; }
        [DisplayName("Last Name")]
        public string LastName { get; set; }
        [DisplayName("Credit Card Number")]
        public string CreditCardNumber { get; set; }
    }
}