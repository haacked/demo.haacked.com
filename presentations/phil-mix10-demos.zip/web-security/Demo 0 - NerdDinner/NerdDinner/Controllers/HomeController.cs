﻿using System.Web.Mvc;
using NerdDinner.Models;

namespace NerdDinner.Controllers {
	[HandleErrorWithELMAH]
    public class HomeController : Controller {
    
        public ActionResult Index() {
            return View();
        }

        public ActionResult About() {
            return View();
        }

        [Authorize]
        [ValidateInput(false)]
        public ActionResult Upgrade(string couponCode) {
            ViewData["couponCode"] = couponCode;
            return View();
        }

        [HttpPost]
        public ActionResult Upgrade(BillingInfo billing) {
            return View("BillingDetails", billing);
        }
    }
}
