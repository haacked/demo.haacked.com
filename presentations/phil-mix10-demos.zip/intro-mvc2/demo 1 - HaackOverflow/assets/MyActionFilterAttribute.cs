﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HaackOverflow.Web.Models;

namespace HaackOverflow.Web
{
    public class MyActionFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var slug = filterContext.RouteData.Values["slug"];
            
            HaackOverflowEntities _data = new HaackOverflowEntities();
            var question = _data.Questions.FirstOrDefault(q => q.Slug == slug);
            filterContext.ActionParameters["question"] = question;

            filterContext.ActionParameters["hashCode"] = 1234;

            base.OnActionExecuting(filterContext);
        }
    }
}