﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel;
using Microsoft.Web.Mvc;
using System.ComponentModel.DataAnnotations;

namespace HaackOverflow.Web.Models
{
    public class QuestionEditModel
    {
        [HiddenInput]
        public int Id { get; set; }
        public string Title { get; set; }
        public string Body { get; set; }

        [DisplayName("Expiration Date")]
        public DateTime? DateExpires { get; set; }

        public void CopyTo(Question question) {
            ModelCopier.CopyModel(this, question);
            question.DateCreated = DateTime.Now;
            question.Views = 0;
            question.Votes = 0;
        }
    }
}