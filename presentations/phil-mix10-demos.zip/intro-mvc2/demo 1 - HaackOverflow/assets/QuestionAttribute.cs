﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using System.Text.RegularExpressions;

namespace HaackOverflow.Web
{
    public class QuestionAttribute : ValidationAttribute
    {
        public bool MustEndWithQuestionMark { get; set; }

        public override bool IsValid(object value)
        {
            if (value == null) {
                return true;
            }
            string input = value as string;
            string pattern = @"(Wh(o|at|en|ere|y)|How)\s.+";
            if (MustEndWithQuestionMark) {
                pattern += @"\?";
            }
            return Regex.IsMatch(input, pattern);
        }

        public override string FormatErrorMessage(string name)
        {
            if (String.IsNullOrEmpty(ErrorMessage) && String.IsNullOrEmpty(ErrorMessageResourceName))
            {
                var message = String.Format("'{0}' must start with 'Who, What, When, Where, Why and How'", name);
                if (MustEndWithQuestionMark) {
                    message += " and end with a question mark";
                }
                return message;
            }
            return base.FormatErrorMessage(name);
        }
    }
}