﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HaackOverflow.Web
{
    public class QuestionValidator 
        : DataAnnotationsModelValidator<QuestionAttribute> 
    {
        string _errorMessage;
        bool _mustEndWithQuestionMark;

        public QuestionValidator(ModelMetadata metadata, ControllerContext context, QuestionAttribute attribute) 
            : base(metadata, context, attribute)
        {
            _errorMessage = attribute.FormatErrorMessage(metadata.PropertyName);
            _mustEndWithQuestionMark = attribute.MustEndWithQuestionMark;
        }

        public override IEnumerable<ModelClientValidationRule> GetClientValidationRules()
        {
            var rule = new ModelClientValidationRule { 
                ErrorMessage = _errorMessage,
                ValidationType = "question"
            };

            rule.ValidationParameters.Add("endWithMark", _mustEndWithQuestionMark);

            yield return rule;
        }
    }
}