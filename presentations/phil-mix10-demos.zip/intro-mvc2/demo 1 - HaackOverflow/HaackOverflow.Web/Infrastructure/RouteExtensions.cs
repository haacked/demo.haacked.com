﻿using System.Web.Mvc;
using System.Web.Routing;

namespace HaackOverflow.Web.Infrastructure
{
    public static class RouteExtensions
    {
        public static Route MapQuestionRoute(this RouteCollection routes, string name, string url, object defaults)
        {
            Route route = new Route(url, new MvcRouteHandler())
            {
                Defaults = new RouteValueDictionary(defaults)
            };
            routes.Add(name, route);
            return route;
        }
    }
}
