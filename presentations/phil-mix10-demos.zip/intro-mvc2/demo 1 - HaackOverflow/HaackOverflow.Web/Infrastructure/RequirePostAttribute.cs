﻿using System;
using System.Reflection;
using System.Web;
using System.Web.Mvc;

namespace HaackOverflow.Web.Infrastructure
{
    public class RequirePostAttribute : ActionMethodSelectorAttribute
    {
        public RequirePostAttribute()
            : this(false)
        {
        }

        public RequirePostAttribute(bool allowCrossSiteRequest)
        {
            AllowCrossSiteRequest = allowCrossSiteRequest;
        }

        public override bool IsValidForRequest(ControllerContext controllerContext, MethodInfo methodInfo)
        {
            if (controllerContext == null)
            {
                throw new ArgumentNullException("controllerContext");
            }

            var request = controllerContext.HttpContext.Request;
            return IsValidForRequest(request);
        }

        private bool IsValidForRequest(HttpRequestBase request)
        {
            string verb = request.HttpMethod;
            if (!string.Equals(verb, "POST", StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            if (!AllowCrossSiteRequest)
            {
                if (request.IsLocal && request.UrlReferrer.Host.Equals("localhost.", StringComparison.OrdinalIgnoreCase))
                {
                    //special case for Fiddler.
                    return true;
                }
                Uri refererUri = request.UrlReferrer;
                Uri currentUri = request.Url;
                if (Uri.Compare(refererUri, currentUri, UriComponents.Host, UriFormat.UriEscaped, StringComparison.OrdinalIgnoreCase) != 0)
                {
                    throw new InvalidOperationException("Cross Site requests are not allowed");
                }
            }
            return true;
        }

        public bool AllowCrossSiteRequest
        {
            get;
            set;
        }
    }
}
