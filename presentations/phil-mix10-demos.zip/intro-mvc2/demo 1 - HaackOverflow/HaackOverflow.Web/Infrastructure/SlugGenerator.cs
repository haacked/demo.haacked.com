﻿using System.Web;

namespace HaackOverflow.Web.Infrastructure
{
    public class SlugGenerator
    {
        public virtual string GetSlug(string title)
        {
            return HttpUtility.UrlEncode(title.Replace(" ", "-").Replace("?", ""));
        }
    }
}
