﻿namespace HaackOverflow.Web.Infrastructure
{
    public enum ActionType
    {
        Display,
        Edit,
        Add,
    }
}
