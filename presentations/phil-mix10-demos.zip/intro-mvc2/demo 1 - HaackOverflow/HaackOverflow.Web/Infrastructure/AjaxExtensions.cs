﻿using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using HaackOverflow.Entities;

namespace HaackOverflow.Web.Infrastructure
{
    public static class AjaxExtensions
    {
        public static MvcHtmlString DeleteAnswerLink(this AjaxHelper ajax, string linkText, Answer answer, AjaxOptions ajaxOptions)
        {
            return ajax.RouteLink(linkText, "answer", 
                new { answerId = answer.Id, action = "delete", slug = answer.Question.Slug }, ajaxOptions);
        }
    }
}
