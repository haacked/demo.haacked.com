﻿using System.Web.Mvc;
using System.Web.Mvc.Html;
using HaackOverflow.Entities;

namespace HaackOverflow.Web.Infrastructure
{
    public static class HtmlExtensions
    {
        public static MvcHtmlString QuestionLink(this HtmlHelper html, Question question)
        {
            return html.QuestionLink(question, question.Title, ActionType.Display);
        }

        public static MvcHtmlString QuestionLink(this HtmlHelper html, Question question, string linkText)
        {
            return html.QuestionLink(question, linkText, ActionType.Display);
        }

        public static MvcHtmlString QuestionLink(this HtmlHelper html, Question question, string linkText, ActionType actionType)
        {
            linkText = string.IsNullOrEmpty(linkText) ? "..." : linkText;
            return html.RouteLink(linkText, "display-question", new { slug = question.Slug, action = actionType.ToString() });
        }
    }
}
