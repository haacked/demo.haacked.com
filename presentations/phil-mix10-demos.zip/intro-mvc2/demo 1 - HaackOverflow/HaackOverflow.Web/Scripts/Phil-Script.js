function flash(selector) {
    $(selector)
	    .css('opacity', 0)
	    .css('backgroundColor', '#ffffff')
        .animate({ backgroundColor: 'khaki', opacity: 1.0 }, 800, function() {
            $(selector).animate({ backgroundColor: '#ffffff' }, 350, function() {
                this.style.removeAttribute('filter');
            });
        });
}

function removeAnswer(context) {
    var data = eval('(' + context.get_data() + ')');
    var item = $('#answers #' + data.deletedId);
    item.css('backgroundColor', '#ffffff')
        .css('opacity', 100)
        .animate({ backgroundColor: 'khaki', opacity: 0 }, 400, function() {
            item.hide();
        });
}
