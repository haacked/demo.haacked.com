﻿Sys.Mvc.ValidatorRegistry.validators["question"] = function (rule) {
    // initialization code can go here.
    var endsWithMark = rule.ValidationParameters["endWithMark"];

    // we return the function that actually does the validation 
    return function (value, context) {
        var regex = /(Wh(o|at|en|ere|y)|How)\s.+/;

        if(endsWithMark && value.substring(value.length - 1) !== '?') {
            return rule.ErrorMessage;
        }

        if (!regex.test(value)) {
            return rule.ErrorMessage;
        }

        return true;
    };
};