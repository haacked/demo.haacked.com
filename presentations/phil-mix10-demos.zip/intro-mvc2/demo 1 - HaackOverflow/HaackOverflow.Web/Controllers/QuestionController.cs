﻿using System;
using System.Linq;
using System.Web.Mvc;
using HaackOverflow.Entities;
using HaackOverflow.Web.Models;

namespace HaackOverflow.Web.Controllers
{
    public class QuestionController : Controller
    {
        public ActionResult Edit(string slug)
        {
            var question = _data.Questions.FirstOrDefault(q => q.Slug == slug);
            return View(question);
        }

        [HttpPost]
        public ActionResult Edit(string slug, Question originalQuestion)
        {
            if (ModelState.IsValid)
            {
                _data.Questions.Attach(originalQuestion);
                
                // Ignoring concurrency for now.
                _data.ObjectStateManager.ChangeObjectState(originalQuestion, System.Data.EntityState.Modified);
                _data.SaveChanges();
                return RedirectToAction("Display", new { slug });
            }
            return Edit(slug);
        }

        #region Ignore the man behind the region curtains
        HaackOverflowEntities _data = new HaackOverflowEntities();

        public ActionResult Display(string slug)
        {
            return View(_data.Questions.FirstOrDefault(q => q.Slug == slug));
        }

        [HttpPost]
        public ActionResult Display(string slug, string answerText)
        {
            var question = _data.Questions.FirstOrDefault(q => q.Slug == slug);
            var answer = new Answer();
            answer.AnswerText = answerText;
            answer.DateCreated = DateTime.Now;
            answer.QuestionId = question.Id;
            question.Answers.Add(answer);
            _data.SaveChanges();

            if (Request.IsAjaxRequest())
            {
                return PartialView("AnswerPartial", answer);
            }

            return RedirectToAction("Display", new { slug = question.Slug });
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                var context = _data;
                if (context != null)
                {
                    context.Dispose();
                }
            }
        }
        #endregion
    }
}
