﻿using System;
using System.Web.Mvc;
using HaackOverflow.Entities;
using HaackOverflow.Web.Infrastructure;
using HaackOverflow.Web.Models;

namespace HaackOverflow.Web.Controllers
{
    [HandleError]
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            var questions = _data.Questions;
            return View(questions);
        }

        public ActionResult Ask()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Ask(Question question)
        {
            question.DateCreated = DateTime.Now;
            question.Votes = 0;
            question.Views = 1;
            question.Slug = _slugGenerator.GetSlug(question.Title);

            _data.Questions.AddObject(question);
            _data.SaveChanges();

            if (Request.IsAjaxRequest())
            {
                return PartialView("QuestionPartial", question);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        public ActionResult About()
        {
            ViewData["Title"] = "About Page";

            return View();
        }

        #region Details Details
        HaackOverflowEntities _data = new HaackOverflowEntities();
        SlugGenerator _slugGenerator = null;
        public HomeController()
            : this(new SlugGenerator())
        {
        }

        public HomeController(SlugGenerator slugGenerator)
        {
            _slugGenerator = slugGenerator;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (_data != null)
                {
                    _data.Dispose();
                }
            }
        }
        #endregion
    }
}
