using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using HaackOverflow.Entities;
using HaackOverflow.Web.Models;

namespace HaackOverflow.Web.Controllers
{
    public class TagController : Controller
    {
        HaackOverflowEntities _context = new HaackOverflowEntities();

        // Being Lazy...
        public ActionResult Index(string filter)
        {
            // TODO: Implement filtering.
            IList<Tag> tags = _context.Tags.ToList();
            return View(tags);
        }
    }
}
