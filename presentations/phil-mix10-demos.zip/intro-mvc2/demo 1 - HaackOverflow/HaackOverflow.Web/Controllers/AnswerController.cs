﻿using System.Linq;
using System.Web.Mvc;
using HaackOverflow.Web.Infrastructure;
using HaackOverflow.Web.Models;

namespace HaackOverflow.Web.Controllers
{
    public class AnswerController : Controller
    {
        HaackOverflowEntities _data = new HaackOverflowEntities();

        [RequirePost]
        public ActionResult Delete(int answerId)
        {
            var answer = _data.Answers.First(a => a.Id == answerId);
            _data.Answers.DeleteObject(answer);
            _data.SaveChanges();
            return Json(new { deletedId = answerId });
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                var context = _data;
                if (context != null)
                {
                    context.Dispose();
                }
            }
        }
    }
}
