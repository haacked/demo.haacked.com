using System.Collections.Generic;

namespace HaackOverflow.Entities
{
    public partial class Tag
    {
        public virtual int Id
        {
            get;
            set;
        }
    
        public virtual string TagName
        {
            get;
            set;
        }
    
        public virtual ICollection<QuestionTag> QuestionTags
        {
            get
            {
                if (_questionTags == null)
                {
                    _questionTags = new List<QuestionTag>();
                }
                return _questionTags;
            }
            set
            {
                _questionTags = value;
            }
        }
        private ICollection<QuestionTag> _questionTags;
    }
}
